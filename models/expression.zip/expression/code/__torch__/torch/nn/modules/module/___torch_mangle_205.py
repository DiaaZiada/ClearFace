op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_203.Module
  pointwise : __torch__.torch.nn.modules.module.___torch_mangle_204.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_205.Module,
    argument_1: Tensor) -> Tensor:
    _0 = (self.pointwise).forward((self.conv1).forward(argument_1, ), )
    return _0
