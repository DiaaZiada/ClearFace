op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  con2d_1 : __torch__.torch.nn.modules.module.___torch_mangle_147.Module
  bn_1 : __torch__.torch.nn.modules.module.___torch_mangle_148.Module
  con2d_2 : __torch__.torch.nn.modules.module.___torch_mangle_149.Module
  bn_2 : __torch__.torch.nn.modules.module.___torch_mangle_150.Module
  block_1 : __torch__.torch.nn.modules.module.___torch_mangle_166.Module
  block_2 : __torch__.torch.nn.modules.module.___torch_mangle_182.Module
  block_3 : __torch__.torch.nn.modules.module.___torch_mangle_198.Module
  block_4 : __torch__.torch.nn.modules.module.___torch_mangle_214.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_215.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_216.Module,
    input: Tensor) -> Tensor:
    _0 = self.block_4
    _1 = self.block_3
    _2 = self.block_2
    _3 = self.block_1
    _4 = self.bn_2
    _5 = self.con2d_2
    _6 = self.relu
    _7 = (self.bn_1).forward((self.con2d_1).forward(input, ), )
    _8 = (_4).forward((_5).forward((_6).forward(_7, ), ), )
    _9 = (_2).forward((_3).forward((_6).forward1(_8, ), ), )
    return (_0).forward((_1).forward(_9, ), )
