op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", ]
  training : bool
  weight : Tensor
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_147.Module,
    input: Tensor) -> Tensor:
    input0 = torch._convolution(input, self.weight, None, [1, 1], [0, 0], [1, 1], False, [0, 0], 1, False, False, True)
    return input0
