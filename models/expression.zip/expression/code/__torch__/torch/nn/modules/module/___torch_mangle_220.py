op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  feature_extractor : __torch__.torch.nn.modules.module.___torch_mangle_216.Module
  classifier : __torch__.torch.nn.modules.module.___torch_mangle_219.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_220.Module,
    input: Tensor) -> Tensor:
    _0 = self.classifier
    _1 = (self.feature_extractor).forward(input, )
    return (_0).forward(_1, )
