op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_319.Module
  pointwise : __torch__.torch.nn.modules.module.___torch_mangle_320.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_321.Module,
    argument_1: Tensor) -> Tensor:
    _0 = (self.pointwise).forward((self.conv1).forward(argument_1, ), )
    return _0
