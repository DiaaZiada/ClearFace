op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  skip : __torch__.torch.nn.modules.module.___torch_mangle_347.Module
  skipbn : __torch__.torch.nn.modules.module.___torch_mangle_348.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_349.Module
  rep : __torch__.torch.nn.modules.module.___torch_mangle_361.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_362.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.skipbn
    _1 = self.skip
    _2 = (self.rep).forward(argument_1, )
    _3 = (_0).forward((_1).forward(argument_1, ), )
    return torch.add_(_2, _3, alpha=1)
