op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv2d_f : __torch__.torch.nn.modules.module.___torch_mangle_447.Module
  glob_avg_bool : __torch__.torch.nn.modules.module.___torch_mangle_448.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_449.Module,
    input: Tensor) -> Tensor:
    _0 = (self.glob_avg_bool).forward((self.conv2d_f).forward(input, ), )
    return _0
