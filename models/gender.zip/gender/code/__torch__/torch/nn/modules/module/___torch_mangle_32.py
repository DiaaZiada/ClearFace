op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_32.Module,
    argument_1: Tensor) -> Tensor:
    x = torch.max_pool2d(argument_1, [3, 3], [2, 2], [1, 1], [1, 1], False)
    return x
