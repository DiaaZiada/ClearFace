op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  feature_extractor : __torch__.torch.nn.modules.module.___torch_mangle_68.Module
  classifier : __torch__.torch.nn.modules.module.___torch_mangle_71.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_72.Module,
    input: Tensor) -> Tensor:
    _0 = self.classifier
    _1 = (self.feature_extractor).forward(input, )
    return (_0).forward(_1, )
